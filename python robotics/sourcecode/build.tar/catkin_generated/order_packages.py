# generated from catkin/cmake/template/order_packages.context.py.in
source_root_dir = "/home/user/catkin_ws/src"
whitelisted_packages = "".split(';') if "" != "" else []
blacklisted_packages = "".split(';') if "" != "" else []
underlay_workspaces = "/home/user/simulation_ws/devel;/home/simulations/public_sim_ws/devel;/opt/ros/kinetic".split(';') if "/home/user/simulation_ws/devel;/home/simulations/public_sim_ws/devel;/opt/ros/kinetic" != "" else []
